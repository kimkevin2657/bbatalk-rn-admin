<template>
  <div>
    <top />
    <div>Room Schedule</div>
  </div>
</template>

<script>
import Top from '../../layouts/component/Top'
export default {
  name: 'RoomSchedule',
  components: {
    Top
  }
}
</script>
