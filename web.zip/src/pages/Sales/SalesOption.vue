<template>
    <div>
        <top />
    </div>
</template>

<script>
import Top from 'src/layouts/component/Top'
export default {
  name: 'SalesOption',
  components: {
    Top
  }
}
</script>
