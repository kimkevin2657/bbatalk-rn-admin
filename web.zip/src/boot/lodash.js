import lodash from 'lodash'
import Vue from 'vue'

window._ = lodash
Vue.prototype._ = lodash
