<template>
  <div>회원 분석 화면</div>
</template>

<script>
export default {
  name: 'MemberAnlysis'
}
</script>
