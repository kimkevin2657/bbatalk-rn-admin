<template>
  <div>
    <top>
    </top>
    <div>talk</div>
  </div>
</template>

<script>
import Top from '../../layouts/component/Top'
export default {
  name: 'Talk',
  components: {
    Top
  }
}
</script>
