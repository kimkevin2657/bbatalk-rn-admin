<template>
  <div>매출 분석 화면</div>
</template>

<script>
export default {
  name: 'SalesAnlysis'
}
</script>
